/* DLA Service Worker – Offline-Betrieb. Bei neuer App-Version die Zahl bei CACHE erhöhen. */
const CACHE='dla-app-v2.5-1';
const FILES=['./','index.html','auswertung.html','manifest.webmanifest','auswertung.webmanifest','icon-192.png','icon-512.png','icon-maskable-512.png','icon-aw-192.png','icon-aw-512.png','icon-aw-maskable-512.png','apple-touch-icon.png','apple-touch-icon-aw.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==location.origin)return;          /* ntfy.sh (Live) und alles Fremde bleibt unberührt */
  e.respondWith(caches.match(r,{ignoreSearch:true}).then(hit=>{
    const net=fetch(r).then(res=>{if(res&&res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(new Request(u.origin+u.pathname),copy))}return res}).catch(()=>hit);
    return hit||net}))});
